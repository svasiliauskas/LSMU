﻿using Microsoft.EntityFrameworkCore;

namespace LSMU_WebApp.Models
{
    public class AppDbContext : DbContext
    {
        public DbSet<Cars> Cars { get; set; }

        public DbSet<Users> Users { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }
    }
}