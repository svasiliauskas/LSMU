﻿namespace LSMU_WebApp.Models
{
    public class Cars
    {
        public int Id { get; set; }
        public required string Company { get; set; }
        public required string CarBrand { get; set; }
        public required string Plate { get; set; }
    }
}
