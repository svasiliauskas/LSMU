﻿using LSMU_WebApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace LSMU_WebApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarsController : Controller
    {
        private readonly AppDbContext _context;

        public CarsController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public ActionResult<IEnumerable<Cars>> GetCars()
        {
            return _context.Cars.ToList();
        }

        [HttpPost]
        public ActionResult<Cars> AddCar(Cars car)
        {
            _context.Cars.Add(car);
            _context.SaveChanges();
            return car;
        }

        [HttpPut]
        public ActionResult<Cars> UpdateCar(Cars car)
        {
            var existingCar = _context.Cars.Find(car.Id);
            if (existingCar == null)
                return NotFound();

            existingCar.Company = car.Company;
            existingCar.CarBrand = car.CarBrand;
            existingCar.Plate = car.Plate;
            _context.SaveChanges();
            return car;
        }

        [HttpDelete]
        public ActionResult<Cars> DeleteCar(int id)
        {
            var car = _context.Cars.Find(id);
            if (car == null)
                return NotFound();

            _context.Cars.Remove(car);
            _context.SaveChanges();
            return NoContent();
        }
    }
}
